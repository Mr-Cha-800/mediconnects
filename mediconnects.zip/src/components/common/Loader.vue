<template>
  <div class="q-pa-md text-center">
    <div class="q-gutter-md">
      <q-spinner
        color="primary"
        size="3em"
      />
    </div>
  </div>
</template>

<script>

  export default {
    name: 'Loader',
  };
</script>

<style lang="scss" scoped>
</style>
