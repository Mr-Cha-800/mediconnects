<template>
  <div class="q-pa-md">
    <div class="q-gutter-md flex fit column justify-center items-center">
      <q-icon name="hourglass_empty" color="primary" size="10rem"></q-icon>
      <span class="text-primary text-h6 text-center">
        No Data
      </span>
    </div>
  </div>
</template>

<script>

  export default {
    name: 'EmptyState',
  };
</script>

<style lang="scss" scoped>
</style>
